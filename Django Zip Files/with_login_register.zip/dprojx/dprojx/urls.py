from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from dappx import views
urlpatterns = [
    path('admin/', admin.site.urls),
    url('$',views.index,name='index'),
    url('special/',views.special,name='special'),
    url('dappx/',include('dappx.urls')),
    url('logout/$', views.user_logout, name='logout'),
]