from django.apps import AppConfig


class DappxConfig(AppConfig):
    name = 'dappx'
